
public enum Method {
		GET,
		POST,
		OPTIONS,
		HEAD,
		TRACE
}
